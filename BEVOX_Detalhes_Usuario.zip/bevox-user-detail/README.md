# BEVOX — Detalhes do Usuário

Réplica visual da área de conteúdo **Detalhes do Usuário**, desenvolvida com React, TypeScript, Vite, CSS e ícones Lucide.

## Escopo desta entrega

- Contém o conteúdo central da tela da referência: título, perfil do usuário, cartões-resumo, abas visuais, dados pessoais, vínculo organizacional, permissões, unidades autorizadas, ações rápidas, últimas atividades e cartão de segurança.
- **Não cria Sidebar global, Header global nem Rodapé.** Esses elementos pertencem ao layout principal do BEVOX e devem ser fornecidos pela aplicação anfitriã.
- A coluna direita foi mantida porque faz parte do conteúdo da tela de referência (status, ações rápidas, atividades e segurança); ela não é a Sidebar global de navegação.
- Os dados exibidos são estáticos e voltados à réplica visual. Não há integração com API, autenticação ou banco de dados.
- Botões, ações rápidas e abas são apenas visuais; ainda não executam operações nem navegação.

## Executar a demonstração isolada

Pré-requisito: Node.js LTS instalado. O ZIP não inclui `node_modules`.

```bash
npm install
npm run dev
```

Abra no navegador a URL local indicada pelo Vite no terminal. Para testar a compilação de produção:

```bash
npm run build
```

Para pré-visualizar a versão compilada, depois do build:

```bash
npm run preview
```

> **Atenção:** não há `package-lock.json` nesta entrega porque a instalação de dependências não foi concluída no ambiente de geração. Quando seu colega instalar as dependências com sucesso, recomenda-se manter o `package-lock.json` gerado no repositório para registrar a árvore de versões resolvida.

## Integrar no projeto BEVOX existente

1. Copie `src/UserDetailsPage.tsx` e `src/UserDetailsPage.css` para a estrutura do projeto anfitrião.
2. Confirme que o projeto já tem `react`, `react-dom` e `lucide-react` instalados.
3. Importe `UserDetailsPage` na rota/área de conteúdo apropriada.
4. Deixe o layout anfitrião renderizar a Sidebar, o Header e o Rodapé existentes.
5. Não substitua `App.tsx`, roteamento, layout global nem configurações do projeto anfitrião sem revisar as diferenças primeiro.

Os seletores CSS da tela são prefixados por `.user-details-page` para reduzir interferência no layout anfitrião. O `index.html` tem resets globais apenas para a demonstração isolada; ele não deve ser copiado para dentro de um projeto existente.

## Documentação incluída

- `DOCUMENTACAO.md`: o que foi feito, como a tela foi estruturada, como executar/integrar e sugestões futuras.
- `REVIEW.md`: pontos fortes, limitações e resultados das verificações.
- `CHANGES.md`: histórico das mudanças feitas nesta revisão.
- `docs/previa-interface-estatica.png`: prévia auxiliar da composição visual. Não é captura de uma execução real do React no navegador.

## Estado da validação

A transpilação sintática dos arquivos TSX passou sem diagnósticos, e o CSS passou por análise sintática. O comando `tsc -b --pretty false` **não passou** porque as dependências (`react`, `react-dom`, `lucide-react`, `vite` e respectivos tipos) não estão instaladas neste ambiente. Por isso, o build completo continua pendente e deve ser repetido após `npm install` em uma máquina com acesso ao registro npm. Consulte `REVIEW.md` para os detalhes.
