import type { ReactNode } from 'react';
import './UserDetailsPage.css';
import type { LucideIcon } from 'lucide-react';
import {
  Building2,
  CalendarDays,
  Check,
  CircleCheck,
  ClipboardCheck,
  Clock3,
  History,
  Info,
  KeyRound,
  LockKeyhole,
  MailPlus,
  MapPin,
  Network,
  Pencil,
  Shield,
  ShieldCheck,
  Trash2,
  UserCog,
  UserRound,
  Zap,
} from 'lucide-react';

type IconType = LucideIcon;

function StatCard({
  icon: Icon,
  label,
  className = '',
  children,
}: {
  icon: IconType;
  label: string;
  className?: string;
  children: ReactNode;
}) {
  return (
    <div className={`stat-card ${className}`}>
      <div className="stat-icon"><Icon size={17} strokeWidth={2} /></div>
      <div className="stat-content">
        <div className="stat-label">{label}</div>
        <div className="stat-value">{children}</div>
      </div>
    </div>
  );
}

function SectionTitle({ icon: Icon, children }: { icon: IconType; children: ReactNode }) {
  return (
    <div className="section-title">
      <Icon size={15} strokeWidth={2} />
      <span>{children}</span>
    </div>
  );
}

function UserDetailsPage() {
  return (
    <main className="user-details-page">
        <div className="page-heading">
          <h1>Detalhes do Usuário</h1>
          <p>Visualize e gerencie as informações, permissões e histórico de acesso do colaborador.</p>
        </div>

        <section className="profile-banner surface">
          <div className="profile-avatar">RS</div>
          <div className="profile-identity">
            <div className="profile-name">Ricardo Silveira</div>
            <div className="profile-state"><span className="small-green-dot" />Ativo</div>
            <div className="profile-email">ricardo@adega.com<br />.br</div>
          </div>
          <div className="profile-actions">
            <button type="button" className="action-button edit-button"><Pencil size={13} strokeWidth={2} />Editar</button>
            <button type="button" className="action-button disable-button"><LockKeyhole size={13} strokeWidth={1.8} />Desativar</button>
            <button type="button" className="action-button delete-button"><Trash2 size={13} strokeWidth={1.9} />Excluir</button>
          </div>
        </section>

        <section className="stats-grid" aria-label="Resumo do usuário">
          <StatCard icon={ShieldCheck} label="Perfil de acesso" className="stat-profile">
            <strong>Administrador Geral</strong>
            <span className="stat-subvalue">Permissão total no sistema</span>
          </StatCard>
          <StatCard icon={Building2} label="Unidade(s) vinculada(s)" className="stat-units">
            <strong>Todas as<br />unidades</strong>
            <span className="stat-subvalue">Acesso completo</span>
          </StatCard>
          <StatCard icon={Clock3} label="Último acesso" className="stat-last-access">
            <strong>17/04/2<br />026 •<br />09:32</strong>
            <span className="online-label"><i />Online</span>
          </StatCard>
          <StatCard icon={CalendarDays} label="Data de cadastro" className="stat-created">
            <strong>10/01/2026<br />• 14:20</strong>
            <span className="stat-subvalue">Por: Admin</span>
          </StatCard>
        </section>

        <div className="tabs-bar" role="tablist" aria-label="Detalhes do usuário">
          <div className="tab-item active-tab" role="tab" aria-selected="true"><ClipboardCheck size={14} />Informações</div>
          <div className="tab-item" role="tab" aria-selected="false"><ShieldCheck size={14} />Permissões</div>
          <div className="tab-item" role="tab" aria-selected="false"><Building2 size={14} />Unidades</div>
          <div className="tab-item" role="tab" aria-selected="false"><History size={14} />Histórico de atividades</div>
        </div>

        <div className="details-layout">
          <div className="left-stack">
            <div className="two-detail-cards">
              <section className="surface detail-card personal-card">
                <SectionTitle icon={UserRound}>Dados pessoais</SectionTitle>
                <div className="field-block field-name">
                  <div className="field-label">NOME COMPLETO</div>
                  <div className="field-value">Ricardo Silveira</div>
                </div>
                <div className="field-grid">
                  <div className="field-block">
                    <div className="field-label">E-MAIL CORPORATIVO</div>
                    <div className="field-value">ricardo@adega.com.br</div>
                  </div>
                  <div className="field-block">
                    <div className="field-label">TELEFONE</div>
                    <div className="field-value">(81) 99999-9999</div>
                  </div>
                </div>
                <div className="field-block field-job">
                  <div className="field-label">CARGO OU FUNÇÃO</div>
                  <div className="field-value">Administrador Geral</div>
                </div>
              </section>

              <section className="surface detail-card organization-card">
                <SectionTitle icon={Network}>Vínculo organizacional</SectionTitle>
                <div className="field-grid org-grid">
                  <div className="field-block">
                    <div className="field-label">UNIDADE PRINCIPAL</div>
                    <div className="field-value">Todas as unidades</div>
                  </div>
                  <div className="field-block">
                    <div className="field-label">PERFIL DE ACESSO</div>
                    <div className="field-value">Administrador Geral</div>
                  </div>
                  <div className="field-block">
                    <div className="field-label">DATA DE INÍCIO</div>
                    <div className="field-value">10/01/2026</div>
                  </div>
                  <div className="field-block">
                    <div className="field-label">DATA DE FIM</div>
                    <div className="field-value muted-dash">—</div>
                  </div>
                </div>
              </section>
            </div>

            <section className="surface permissions-card">
              <div className="permissions-heading-row">
                <SectionTitle icon={Shield}>Permissões e acesso</SectionTitle>
                <span className="global-access-label">ACESSO GLOBAL</span>
              </div>
              <div className="field-label permissions-summary-label">RESUMO DAS PERMISSÕES</div>
              <div className="permissions-summary">Acesso total a todos os módulos do sistema.</div>
              <div className="permission-info"><Info size={14} strokeWidth={2} /><span>Este usuário possui permissões de administrador, podendo gerenciar usuários, unidades, configurações e todos os módulos da plataforma.</span></div>
              <div className="field-label modules-label">MÓDULOS COM ACESSO</div>
              <div className="modules-grid">
                <div className="module-column">
                  <div className="module-item"><CircleCheck />Dashboard</div>
                  <div className="module-item"><CircleCheck />Documentos</div>
                  <div className="module-item"><CircleCheck />Licenças e Alvarás</div>
                  <div className="module-item"><CircleCheck />Tarefas</div>
                  <div className="module-item"><CircleCheck />Operações e Resultados</div>
                  <div className="module-item"><CircleCheck />Financeiro</div>
                </div>
                <div className="module-column">
                  <div className="module-item"><CircleCheck />Estoque</div>
                  <div className="module-item"><CircleCheck />Logística</div>
                  <div className="module-item"><CircleCheck />Relatórios e Indicadores</div>
                  <div className="module-item"><CircleCheck />Usuários e Permissões</div>
                  <div className="module-item"><CircleCheck />Configurações</div>
                </div>
              </div>
            </section>

            <section className="surface authorized-units-card">
              <SectionTitle icon={MapPin}>Unidades autorizadas</SectionTitle>
              <div className="authorized-description">Acesso a todas as unidades da empresa.</div>
              <div className="unit-chips">
                <span className="unit-chip"><Building2 />Matriz — Recife</span>
                <span className="unit-chip"><Building2 />Paulista</span>
                <span className="unit-chip"><Building2 />Jaboatão</span>
                <span className="unit-chip"><Building2 />Olinda</span>
                <span className="unit-chip"><Building2 />Caruaru</span>
                <span className="unit-chip"><Building2 />Outras unidades</span>
              </div>
            </section>
          </div>

          <div className="right-stack">
            <section className="surface status-card">
              <div className="status-check"><Check size={16} strokeWidth={3} /></div>
              <div><div className="status-title">Usuário ativo</div><div className="status-description">Com acesso habilitado ao sistema.</div></div>
            </section>

            <section className="surface quick-actions-card">
              <div className="compact-card-heading"><Zap size={13} strokeWidth={2} /><span>AÇÕES RÁPIDAS</span></div>
              <div className="quick-action-row"><span className="quick-action-icon"><UserCog /></span><span>Alterar perfil</span></div>
              <div className="quick-action-row"><span className="quick-action-icon"><Building2 /></span><span>Gerenciar unidades</span></div>
              <div className="quick-action-row"><span className="quick-action-icon"><KeyRound /></span><span>Resetar senha</span></div>
              <div className="quick-action-row"><span className="quick-action-icon"><MailPlus /></span><span>Enviar novo convite</span></div>
            </section>

            <section className="surface activities-card">
              <div className="compact-card-heading activities-heading"><History size={13} strokeWidth={2} /><span>ÚLTIMAS ATIVIDADES</span></div>
              <div className="activity-timeline">
                <div className="activity-item activity-green">
                  <span className="timeline-dot" />
                  <div className="activity-title">Login realizado</div>
                  <div className="activity-time">17/04/2026 • 09:32</div>
                  <div className="activity-detail">IP 192.168.1.10</div>
                </div>
                <div className="activity-item activity-blue">
                  <span className="timeline-dot" />
                  <div className="activity-title">Perfil de acesso alterado</div>
                  <div className="activity-time">14/04/2026 • 16:20</div>
                  <div className="activity-detail">Por: Ricardo Silveira</div>
                </div>
                <div className="activity-item activity-amber">
                  <span className="timeline-dot" />
                  <div className="activity-title">Unidade vinculada</div>
                  <div className="activity-time">10/04/2026 • 11:45</div>
                  <div className="activity-detail">Matriz — Recife</div>
                </div>
                <div className="activity-item activity-red">
                  <span className="timeline-dot" />
                  <div className="activity-title">Usuário criado</div>
                  <div className="activity-time">10/01/2026 • 14:20</div>
                  <div className="activity-detail">Por: Admin</div>
                </div>
              </div>
            </section>

            <section className="security-card">
              <div className="security-icon"><ShieldCheck size={15} strokeWidth={2} /></div>
              <div className="security-copy"><div className="security-title">Segurança</div><div className="security-description">Todas as ações são registradas em log para auditoria e rastreabilidade.</div></div>
            </section>
          </div>
        </div>
    </main>
  );
}

export default UserDetailsPage;
