import UserDetailsPage from './UserDetailsPage';

export default function App() {
  return <UserDetailsPage />;
}
